//
//  NALottieAnimationView.swift
//  NASleep
//
//  Created by NA01 on 2023/12/19.
//

import UIKit
import Foundation
import Lottie
import Masonry

@objc
public enum NALottieBackgroundBehavior:Int {
    case na_default = 0
    case na_stop = 1
    case na_pause = 2
    case na_pauseAndRestore = 3
    case na_forceFinish = 4
    case na_continuePlaying = 5
}

@objc
open class NALottieAnimationView: UIView {
    //动画
    @objc public var mAnimationView = LottieAnimationView()
    
    ///次数
    @objc public var loopAnimationCount: CGFloat = 0 {
        didSet {
            mAnimationView.loopMode = loopAnimationCount == -1 ? .loop : .repeat(Float(loopAnimationCount))
        }
    }
    
    /// 速度
    @objc public var speed: CGFloat = 1 {
        didSet {
            mAnimationView.animationSpeed = speed
        }
    }
    
    @objc public var progress: CGFloat = 0 {
        didSet {
            mAnimationView.currentProgress = progress
        }
    }
    
    @objc public var animationContentMode: UIView.ContentMode = .scaleToFill {
        didSet {
            mAnimationView.contentMode = animationContentMode
        }
    }
    
    /// 程序到后台动画的行为
    @objc public var backgroundBehavior: NALottieBackgroundBehavior = .na_default {
        didSet {
            switch backgroundBehavior {
            case .na_stop:
                mAnimationView.backgroundBehavior = .stop
            case.na_pause:
                mAnimationView.backgroundBehavior = .pause
            case.na_pauseAndRestore:
                mAnimationView.backgroundBehavior = .pauseAndRestore
            case.na_continuePlaying:
                mAnimationView.backgroundBehavior = .continuePlaying
            case .na_forceFinish:
                mAnimationView.backgroundBehavior = .forceFinish
            case .na_default:
                break
            }
        }
    }
    
    public init() {
        self.speed = 1
        self.loopAnimationCount = 0
        self.backgroundBehavior = .na_default
        super.init(frame: .zero)
    }
    
    ///名称--创建动画
    @objc public convenience init(name: String) {
        self.init()
        if let jsonPath = Bundle.main.path(forResource: name, ofType: "json"),
           let animation = LottieAnimation.filepath(jsonPath) {
            mAnimationView.animation = animation
            self.addSubview(mAnimationView)
            mAnimationView.mas_makeConstraints { make in
                make?.left.mas_equalTo()(0)
                make?.right.mas_equalTo()(0)
                make?.top.mas_equalTo()(0)
                make?.bottom.mas_equalTo()(0)
            }
            mAnimationView.play()
        }
    }
    
    @objc public convenience init(jsonPath: String) {
        self.init()
        if let animation = LottieAnimation.filepath(jsonPath) {
            mAnimationView.animation = animation
            self.addSubview(mAnimationView)
            mAnimationView.mas_makeConstraints { make in
                make?.left.mas_equalTo()(0)
                make?.right.mas_equalTo()(0)
                make?.top.mas_equalTo()(0)
                make?.bottom.mas_equalTo()(0)
            }
            mAnimationView.play()
        }
    }
    
    ///远层--创建动画
    @objc public convenience init(remoteUrl:String) {
        self.init()
        weak var weakSelf = self
        if let url = URL(string: remoteUrl) {
            mAnimationView = LottieAnimationView(url:url, closure: { (error) in
                if let _ = error {
                    DispatchQueue.main.async {
                        weakSelf?.remove()
                    }
                } else {
                    DispatchQueue.main.async {
                        weakSelf?.showRemoteLottieWhenSuccess()
                    }
                }
            })
        }
    }
    
    ///远层动画成功
    fileprivate func showRemoteLottieWhenSuccess() {
        mAnimationView.contentMode = .scaleAspectFit
        self.addSubview(mAnimationView)
        mAnimationView.mas_makeConstraints { make in
            make?.left.mas_equalTo()(0)
            make?.right.mas_equalTo()(0)
            make?.top.mas_equalTo()(0)
            make?.bottom.mas_equalTo()(0)
        }
        mAnimationView.play()
    }
    
    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    ///播放动画
    @objc open func play(completion:@escaping (_ finished :Bool) -> ()) {
        mAnimationView.play(completion: completion)
    }
    
    @objc open func play(
        fromProgress: AnimationFrameTime,
        toProgress: AnimationFrameTime,
        loopAnimation: Bool,
        completion:@escaping (_ finished :Bool) -> ()) {
            mAnimationView.play(fromProgress: fromProgress, toProgress: toProgress,loopMode: loopAnimation ? .loop : .playOnce , completion: completion);
        }
    
    @objc open func play(
        toProgress: AnimationFrameTime,
      completion:@escaping (_ finished :Bool) -> ()) {
          mAnimationView.play(toProgress: toProgress, completion: completion)
      }
    
    ///播放动画
    @objc public func play() -> Void {
        mAnimationView.play()
    }
    
    ///暂停动画
    @objc public func pause() -> Void {
        mAnimationView.pause();
    }
    
    ///停止动画
    @objc public func stop() -> Void {
        mAnimationView.stop();
    }
    
    ///删除动画
    @objc public func remove() -> Void {
        mAnimationView.removeFromSuperview()
        self.removeFromSuperview()
    }
}
