//
//  LOTAnimationView.h
//  NASleep
//
//  Created by NA01 on 2023/12/19.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "LottieDemo-Swift.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOTAnimationView : UIView

@property (nonatomic, strong,readonly) NALottieAnimationView *animationView;

@property (nonatomic, assign) CGFloat progress;
@property (nonatomic, strong) UIColor *backgroundColor;
@property (nonatomic, assign) UIViewContentMode contentMode;
@property (nonatomic, assign) BOOL loopAnimation;

+ (instancetype)animationWithFilePath:(nonnull NSString *)filePath;
+ (instancetype)animationNamed:(nonnull NSString *)animationName;

- (void)play;
- (void)playWithCompletion:(void(^)(BOOL animationFinished))completion;
- (void)playFromProgress:(CGFloat)fromStartProgress
              toProgress:(CGFloat)toEndProgress
           loopAnimation:(BOOL)loopAnimation
          withCompletion:(void(^)(BOOL animationFinished))completion;
- (void)playToProgress:(CGFloat)toProgress
        withCompletion:(void(^)(BOOL animationFinished))completion;
- (void)stop;
- (void)pause;

@end

NS_ASSUME_NONNULL_END
