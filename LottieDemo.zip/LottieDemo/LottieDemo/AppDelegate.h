//
//  AppDelegate.h
//  LottieDemo
//
//  Created by 全栈会 on 2022/1/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic) UIWindow * window;


@end

