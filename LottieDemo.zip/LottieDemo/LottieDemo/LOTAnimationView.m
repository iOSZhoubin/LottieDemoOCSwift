//
//  LOTAnimationView.m
//  NASleep
//
//  Created by NA01 on 2023/12/19.
//

#import "LOTAnimationView.h"

@interface LOTAnimationView()

@property (nonatomic, strong,readwrite) NALottieAnimationView *animationView;

@end

@implementation LOTAnimationView

+ (instancetype )animationWithFilePath:(nonnull NSString *)filePath {
    LOTAnimationView *animationView = [[LOTAnimationView alloc] init];
    animationView.userInteractionEnabled = NO;
    NALottieAnimationView *aniView = [[NALottieAnimationView alloc] initWithJsonPath:filePath];
    aniView.speed = 1;
    aniView.loopAnimationCount = 1;
    aniView.userInteractionEnabled = NO;

    [animationView addSubview:aniView];
    animationView.animationView = aniView;
    [aniView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_offset(0);
    }];
    
    return animationView;
}

+ (instancetype)animationNamed:(nonnull NSString *)animationName {
    LOTAnimationView *animationView = [[LOTAnimationView alloc] init];
    animationView.userInteractionEnabled = NO;
    NALottieAnimationView *aniView = [[NALottieAnimationView alloc] initWithName:animationName];
    aniView.speed = 1;
    aniView.loopAnimationCount = 1;
    aniView.userInteractionEnabled = NO;

    [animationView addSubview:aniView];
    animationView.animationView = aniView;
    [aniView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_offset(0);
    }];
    
    return animationView;
}

#pragma mark -Setter
- (void)setBackgroundColor:(UIColor *)backgroundColor {
    self.animationView.backgroundColor = backgroundColor;
}

- (void)setLoopAnimation:(BOOL)loopAnimation {
    self.animationView.loopAnimationCount = loopAnimation ? -1 : 1;
}

- (void)setContentMode:(UIViewContentMode)contentMode {
    self.animationView.animationContentMode = contentMode;
}

- (void)play {
    [self.animationView play];
}

- (void)stop {
    [self.animationView stop];
}

- (void)pause {
    [self.animationView pause];
}

- (void)playWithCompletion:(void(^)(BOOL animationFinished))finishBlock {
    [self.animationView playWithCompletion:finishBlock];
}

- (void)playFromProgress:(CGFloat)fromStartProgress
              toProgress:(CGFloat)toEndProgress
           loopAnimation:(BOOL)loopAnimation
          withCompletion:(void(^)(BOOL animationFinished))completion {
    [self.animationView playFromProgress:fromStartProgress toProgress:toEndProgress loopAnimation:loopAnimation completion:completion];
}

- (void)playToProgress:(CGFloat)toProgress
        withCompletion:(void(^)(BOOL animationFinished))completion {
    [self.animationView playToProgress:toProgress completion:completion];
}

- (void)setProgress:(CGFloat)progress {
    [self.animationView setProgress:progress];
}

@end
