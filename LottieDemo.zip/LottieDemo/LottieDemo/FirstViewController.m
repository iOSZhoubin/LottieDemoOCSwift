//
//  FirstViewController.m
//  LottieDemo
//
//  Created by 全栈会 on 2022/1/26.
//

#import "FirstViewController.h"
#import "LOTAnimationView.h"


@interface FirstViewController ()

@property (weak, nonatomic) IBOutlet UIView *animalView;

@property (strong,nonatomic) LOTAnimationView *animation;



@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initAnimal];
}

-(void)initAnimal
{
    self.animation = [LOTAnimationView animationNamed:@"servishero-loading_1"];
            
    self.animation.frame = CGRectMake(0, 0, self.animalView.frame.size.width, self.animalView.frame.size.height);
    
    [self.animalView addSubview:self.animation];
}


- (IBAction)startAnimal:(UIButton *)sender {
        
    NSLog(@"开始动画");
    self.animation.loopAnimation = YES; // 让动画一直执行
    [self.animation playWithCompletion:^(BOOL animationFinished) {
        // 动画停止后要做的事情
        NSLog(@"动画停止");
    }];
}


- (IBAction)stopAnimal:(UIButton *)sender {
    
    NSLog(@"停止动画");
    [self.animation stop];
}

@end
